package com.hadi.realoneplayer

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private var all: List<VideoItem> = emptyList()
    private lateinit var adapter: VideoAdapter
    private lateinit var searchInput: EditText
    private lateinit var titleText: TextView
    private var pendingResume = false

    private val permission =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) refresh() else Toast.makeText(this, "Izin akses video diperlukan", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Lanjutkan video terakhir hanya saat aplikasi benar-benar baru dibuka
        pendingResume = savedInstanceState == null

        titleText = findViewById(R.id.titleText)
        searchInput = findViewById(R.id.searchInput)
        val list = findViewById<RecyclerView>(R.id.list)
        adapter = VideoAdapter { openVideo(it) }
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        findViewById<ImageButton>(R.id.searchBtn).setOnClickListener { toggleSearch() }
        searchInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = applyFilter()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        if (!hasPermission()) permLauncher.launch(permission)
    }

    override fun onResume() {
        super.onResume()
        if (hasPermission()) refresh()
    }

    private fun hasPermission() =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun refresh() {
        all = VideoRepo.load(this)
        applyFilter()
        if (pendingResume) {
            pendingResume = false
            val prefs = getSharedPreferences(PlayerActivity.PREFS, Context.MODE_PRIVATE)
            val uri = prefs.getString("uri", null)
            if (uri != null && all.any { it.uri.toString() == uri }) {
                startActivity(Intent(this, PlayerActivity::class.java).putExtra("uri", uri))
            }
        }
    }

    private fun applyFilter() {
        val q = searchInput.text.toString().trim()
        adapter.submit(if (q.isEmpty()) all else all.filter { it.title.contains(q, ignoreCase = true) })
    }

    private fun toggleSearch() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (searchInput.visibility == View.GONE) {
            titleText.visibility = View.GONE
            searchInput.visibility = View.VISIBLE
            searchInput.requestFocus()
            imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        } else {
            searchInput.setText("")
            searchInput.visibility = View.GONE
            titleText.visibility = View.VISIBLE
            imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
        }
    }

    private fun openVideo(v: VideoItem) {
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("uri", v.uri.toString()))
    }
}

class VideoAdapter(private val onClick: (VideoItem) -> Unit) : RecyclerView.Adapter<VideoAdapter.VH>() {
    private var items: List<VideoItem> = emptyList()

    fun submit(list: List<VideoItem>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.vTitle)
        val dur: TextView = v.findViewById(R.id.vDuration)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_video, p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val v = items[i]
        h.title.text = v.title
        h.dur.text = VideoRepo.time(v.durationMs)
        h.itemView.setOnClickListener { onClick(v) }
    }

    override fun getItemCount() = items.size
}
