package com.hadi.realoneplayer

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class VideoItem(val id: Long, val title: String, val uri: Uri, val durationMs: Long)

object VideoRepo {
    /** Mengambil semua video (semua format) yang dikenali MediaStore. */
    fun load(ctx: Context): List<VideoItem> {
        val list = mutableListOf<VideoItem>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION
        )
        ctx.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, null, null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val name = (c.getString(iName) ?: "Video").substringBeforeLast('.')
                val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                list.add(VideoItem(id, name, uri, c.getLong(iDur)))
            }
        }
        return list
    }

    fun time(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d.%02d.%02d".format(h, m, sec) else "%02d.%02d".format(m, sec)
    }
}
