package com.hadi.realoneplayer

import android.content.Context
import android.graphics.Color
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.LoudnessEnhancer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {

    companion object { const val PREFS = "resume" }

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var controls: View
    private lateinit var videoTitle: TextView
    private lateinit var curTime: TextView
    private lateinit var totalTime: TextView
    private lateinit var seek: SeekBar
    private lateinit var playBtn: ImageButton
    private lateinit var boostBtn: ImageButton
    private lateinit var subBtn: ImageButton
    private lateinit var lockBtn: ImageButton

    private var videos: List<VideoItem> = emptyList()
    private var index = 0
    private var locked = false
    private var boost = false
    private var subsOn = true
    private var dragging = false
    private var intentionalExit = false
    private var tick = 0

    private var loudness: LoudnessEnhancer? = null
    private var bass: BassBoost? = null

    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable {
        controls.visibility = View.GONE
        lockBtn.visibility = View.GONE
    }
    private val ticker = object : Runnable {
        override fun run() {
            if (!dragging) {
                seek.progress = player.currentPosition.toInt()
                curTime.text = VideoRepo.time(player.currentPosition)
            }
            // simpan posisi berkala supaya bisa lanjut jika aplikasi tertutup mendadak
            if (++tick % 4 == 0) saveResume()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)
        hideSystemUi()

        playerView = findViewById(R.id.playerView)
        controls = findViewById(R.id.controls)
        videoTitle = findViewById(R.id.videoTitle)
        curTime = findViewById(R.id.curTime)
        totalTime = findViewById(R.id.totalTime)
        seek = findViewById(R.id.seek)
        playBtn = findViewById(R.id.playBtn)
        boostBtn = findViewById(R.id.boostBtn)
        subBtn = findViewById(R.id.subBtn)
        lockBtn = findViewById(R.id.lockBtn)

        videos = VideoRepo.load(this)
        val uriStr = intent.getStringExtra("uri")
        if (videos.isEmpty() || uriStr == null) { finish(); return }
        index = videos.indexOfFirst { it.uri.toString() == uriStr }.coerceAtLeast(0)

        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playBtn.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) {
                    val d = player.duration.coerceAtLeast(0)
                    seek.max = d.toInt()
                    totalTime.text = VideoRepo.time(d)
                } else if (state == Player.STATE_ENDED) {
                    if (index < videos.size - 1) playIndex(index + 1, 0) else exitPlayer()
                }
            }
            override fun onAudioSessionIdChanged(audioSessionId: Int) = setupEffects(audioSessionId)
        })
        setupEffects(player.audioSessionId)

        findViewById<ImageButton>(R.id.backBtn).setOnClickListener { exitPlayer() }
        onBackPressedDispatcher.addCallback(this) {
            if (locked) Toast.makeText(this@PlayerActivity, "Layar terkunci", Toast.LENGTH_SHORT).show()
            else exitPlayer()
        }
        playBtn.setOnClickListener { if (player.isPlaying) player.pause() else player.play(); showControls() }
        findViewById<ImageButton>(R.id.prevBtn).setOnClickListener {
            if (index > 0) playIndex(index - 1, 0) else player.seekTo(0)
            showControls()
        }
        findViewById<ImageButton>(R.id.nextBtn).setOnClickListener {
            if (index < videos.size - 1) playIndex(index + 1, 0)
            showControls()
        }
        boostBtn.setOnClickListener { boost = !boost; applyBoost(); showControls() }
        subBtn.setOnClickListener { subsOn = !subsOn; applySubs(); showControls() }
        lockBtn.setOnClickListener {
            locked = !locked
            lockBtn.setImageResource(if (locked) R.drawable.ic_lock else R.drawable.ic_unlock)
            showControls()
        }
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        findViewById<ImageButton>(R.id.volUpBtn).setOnClickListener {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            showControls()
        }
        findViewById<ImageButton>(R.id.volDownBtn).setOnClickListener {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            showControls()
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) curTime.text = VideoRepo.time(p.toLong())
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { dragging = true; handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
                player.seekTo(seek.progress.toLong())
                showControls()
            }
        })
        playerView.setOnClickListener {
            if (lockBtn.visibility == View.VISIBLE) { handler.removeCallbacks(hideRunnable); hideRunnable.run() }
            else showControls()
        }

        // lanjutkan dari posisi tersimpan bila video yang sama
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val start = if (prefs.getString("uri", null) == videos[index].uri.toString())
            prefs.getLong("pos", 0) else 0L
        playIndex(index, start)
        applyBoost()
        showControls()
        handler.post(ticker)
    }

    private fun playIndex(i: Int, startMs: Long) {
        index = i
        videoTitle.text = videos[i].title
        seek.progress = 0
        player.setMediaItem(MediaItem.fromUri(videos[i].uri), startMs)
        player.prepare()
        player.playWhenReady = true
        applySubs()
    }

    // Bass / volume boost sampai 200% (+6 dB)
    private fun setupEffects(session: Int) {
        releaseEffects()
        if (session == C.AUDIO_SESSION_ID_UNSET || session == 0) return
        try { loudness = LoudnessEnhancer(session) } catch (_: Exception) {}
        try { bass = BassBoost(0, session) } catch (_: Exception) {}
        applyBoost()
    }

    private fun applyBoost() {
        try { loudness?.setTargetGain(if (boost) 600 else 0); loudness?.setEnabled(boost) } catch (_: Exception) {}
        try { bass?.setStrength((if (boost) 1000 else 0).toShort()); bass?.setEnabled(boost) } catch (_: Exception) {}
        boostBtn.setColorFilter(if (boost) Color.RED else Color.WHITE)
    }

    private fun releaseEffects() {
        try { loudness?.release() } catch (_: Exception) {}
        try { bass?.release() } catch (_: Exception) {}
        loudness = null; bass = null
    }

    private fun applySubs() {
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subsOn).build()
        subBtn.alpha = if (subsOn) 1f else 0.4f
    }

    private fun showControls() {
        handler.removeCallbacks(hideRunnable)
        controls.visibility = if (locked) View.GONE else View.VISIBLE
        lockBtn.visibility = View.VISIBLE
        handler.postDelayed(hideRunnable, 4000)
    }

    private fun hideSystemUi() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    private fun saveResume() {
        if (!::player.isInitialized || intentionalExit) return
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("uri", videos[index].uri.toString())
            .putLong("pos", player.currentPosition)
            .apply()
    }

    private fun exitPlayer() {
        intentionalExit = true
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        finish()
    }

    override fun onStop() {
        super.onStop()
        if (::player.isInitialized) {
            saveResume()
            player.pause()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releaseEffects()
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}
